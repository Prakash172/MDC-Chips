package com.prakash.pr20020897.chipsexample;

import android.support.design.chip.Chip;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Chip action,choice, entry, filter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        action = findViewById(R.id.action);
        choice = findViewById(R.id.choice);
        entry = findViewById(R.id.entry);
        filter = findViewById(R.id.filter);
        
        entry.setOnCloseIconClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Closed button is clicked", Toast.LENGTH_SHORT).show();
                entry.setVisibility(View.GONE);
            }
        });
    }
}
